# WFA - Selfbot v4
## WFA Selfbot Is A Token Grabber.
![](https://raw.githubusercontent.com/WFA-Selfbot/wfa-selfbot/main/assets/wfa-background.png)


<h1 align="center">
  WFA Selfbot V4 🔰
</h1>


<h2 align="center">
  WFA - Selfbot was made with

Love ❌ Skid ✅

</h2>

**NOTE:** \
wfa - selfbot was made for educational purposes, therefor all consequences caused by your actions are **your** responsibility and accountability.

---

## <a id="content"></a>🌐 〢 Content

- [🔰・Features](#features)
- [🌌・Discord](https://discord.gg/qXM2j4BmCu)
- [🎉・Setting up WFA - Selfbot](#setup)
- [⚙・Config](#config)
- [📝・Changelog](#changelog)

## <a id="features"></a>🔰 〢 Features

```
> Commands Raid
> Lock Group
> Token Grabber detector
> Commands Utils
> Commands """Hack"""
> Commands Troll
> Commands Moderation
> Tokens Manager
> Commands Activities
> Discord Support
> + More!
```



## <a id="setup"></a> 📁 〢 Setting up WFA - Selfbot

1. Install [Nodejs](https://nodejs.org/)
2. Open up [config.json](https://github.com/WFA-Selfbot/wfa-selfbot/blob/main/config.json) with notepad or some other editor
3. Double Click on [start.bat](https://github.com/WFA-Selfbot/wfa-selfbot/blob/main/start.bat)




## <a id="config"></a>⚙ 〢 Config

If you want to change the config, open up [config.json](https://github.com/WFA-Selfbot/wfa-selfbot/blob/main/config.json) and locate it at the top. There you can configure the following:

```json
{
    "token": "NzgxMjA0ODUyOTEwOTgxMTYz.GkAM43.t0y1bsPwdKBkfIoU_LWh04eOtNcekjPbCFwRz0", // place your token like example
    "prefix": "!", //you can change it
    "language": "en", //only en - fr allowed
    "nsfw": "off", //disable or enable nsfw commands
    "version": "4.5.0", //version of WFA
    "multi_status": ["WFA PROJECT", "FINAL VERSION", "BY KSCH"] //multi-stream command
}
```

---


## <a id="changelog"></a>💭 〢 ChangeLog

```diff
v4.5.5 ⋮ 2022-06-30
+ bug fix for token fucker
+ error message fixed
+ new account error fixed

```

<a href=#top>Back to Top</a></p>
